import React from "react";

const Destinations = () => {
  return <div>Destinations</div>;
};

export default Destinations;
